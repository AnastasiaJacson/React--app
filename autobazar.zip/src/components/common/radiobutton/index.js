const Radiobutton = ({ valueRef, onChange, htmlIdPrefix, values, valueProp, labelProp, errorMessage }) => {
  const radio = values.map((v, i) => (
    <label htmlFor={`${htmlIdPrefix}-${v[valueProp]}`} key={i}>
      <input
        type="radio"
        id={`${htmlIdPrefix}-${v[valueProp]}`}
        value={v[valueProp]}
        checked={valueRef === v[valueProp]}
        onChange={() => onChange(v[valueProp])} />
      {v[labelProp]}
    </label>
  ));

  return (
    <div className="mb-6">
      {radio}
    </div>
  );
};

export default Radiobutton;
