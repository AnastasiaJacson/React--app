const About = () => {
  return (
    <div>
      <h1>Auto Bazar</h1>
      <h2>Created by: Anastasiia Vynnychuk</h2>
    </div>
  )
};

export default About;
