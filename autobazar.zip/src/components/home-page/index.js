import { useState } from "react";
import { useDataStorageContext } from "../../contexts/data-storage-context";
import CarList from "../car-list";
import TextInput from "../common/text-input";
import './style.css';

const HomePage = () => {
  const { state, dispatch } = useDataStorageContext();

  const [pageNum, setPageNum] = useState(1);
  const pageSize = 5;
  const [filterTitle, setFilterTitle] = useState('');

  let filteredCars = Object.entries(state.cars)
    .map(([cId, c]) => ({ id: cId, data: c }))
    .filter(c => {
      if (!filterTitle) {
        return true;
      }
      const brandContains = state.brands[c.data.brandId].name.toLowerCase().includes(filterTitle.toLowerCase());
      const modelContains = state.brands[c.data.brandId].models[c.data.modelId].name.toLowerCase().includes(filterTitle.toLowerCase());

      return brandContains || modelContains;
    });
  
  const maxPageNum = Math.ceil(filteredCars.length / pageSize);
  filteredCars = filteredCars.slice((pageNum - 1) * pageSize, pageNum * pageSize);

  const prevPage = () => {
    if (pageNum > 1) {
      setPageNum(pageNum - 1);
    }
  };

  const nextPage = () => {
    if (pageNum < maxPageNum) {
      setPageNum(pageNum + 1);
    }
  };

  const pageNumbers = [...Array(maxPageNum).keys()]
    .map(v => v + 1)
    .map((pn, i) => (
      <li key={i}>
        <span onClick={() => setPageNum(pn)} className={`cursor-pointer py-2 px-3 ${pageNum === pn ? "active-page" : "page-entry"}`}>{pn}</span>
      </li>
    ));

  return (
    <div>
      <TextInput htmlId="search-title" label="Search title:" onChange={evt => setFilterTitle(evt.target.value)} placeholder="Filter title..." valueRef={filterTitle} />
      <CarList cars={filteredCars} onDelete={id => {}} />

      <nav className="mt-6" aria-label="Page navigation example">
        <ul className="inline-flex -space-x-px">
          <li>
            <span onClick={prevPage} className="cursor-pointer py-2 px-3 page-entry">Previous</span>
          </li>
          {pageNumbers}
          <li>
            <span onClick={nextPage} className=" cursor-pointer py-2 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">Next</span>
          </li>
        </ul>
      </nav>
    </div>
  )
};

export default HomePage;
