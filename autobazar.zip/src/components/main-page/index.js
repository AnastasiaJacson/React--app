import { BrowserRouter, Route, Routes } from 'react-router-dom';
import About from '../About';
import AddCar from '../add-car';
import Navbar from '../common/Navbar';
import EditCar from '../edit-car';
import HomePage from '../home-page';

const MainPage = () => {
  return (
    <div>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path='/' element={<HomePage />} />
          <Route path='/edit-car/:carId' element={<EditCar />} />
          <Route path='/add-car' element={<AddCar />} />
          <Route path='/about' element={<About />} />
        </Routes>
      </BrowserRouter>
    </div>
  )
};

export default MainPage;
